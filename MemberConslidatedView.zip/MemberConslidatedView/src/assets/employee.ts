
export interface IEmployee{
    memId : string, 
    FirstName : string,
    LastName : string,
    SSN : string,
    CIN : string
}