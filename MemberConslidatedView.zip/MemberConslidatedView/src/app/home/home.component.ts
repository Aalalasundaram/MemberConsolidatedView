import { Component, OnInit } from '@angular/core';
import { EmployeelistService } from '../employeelist.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private _employeeListService: EmployeelistService ) { }

  ngOnInit() {    
  }

  memberList = [];

  searchMember(): void {        
    this._employeeListService.getEmployeelist().subscribe(data => this.memberList = data);
  }

  firstname : string;
  hpid : string;
  ssnval : string;
  dobval : string;
  zipcodeval : string;
  homephoneval : string;

  submit() {
    if((this.firstname != '' && this.firstname != undefined)     
    || (this.hpid != '' && this.hpid != undefined)
    || (this.ssnval != '' && this.ssnval != undefined)
    || (this.dobval != '' && this.dobval != undefined)
    || (this.zipcodeval != '' && this.zipcodeval != undefined)
    || (this.homephoneval != '' && this.homephoneval != undefined))
    {   
        this.searchMember();
    }   
    else
    {
      this.memberList = [];
      alert('Please fill any one input value');
    }   
  }
  
}
