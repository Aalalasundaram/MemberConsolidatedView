import { Component, OnInit } from '@angular/core';
import { ExcelService } from '../excel.service';

@Component({
  selector: 'app-enrollment',
  templateUrl: './enrollment.component.html',
  styleUrls: ['./enrollment.component.css']
})
export class EnrollmentComponent implements OnInit {

  constructor(private excelService: ExcelService) { }  
  ngOnInit() {    
    this.onChange('HBEX');
  }  
  
  title: string;
  enrollmentDetails = [];
  memberDetails = [];

  onChange(program) {
    if(program=="HBEX"){
      this.enrollmentDetails = [      
        { program: "HBEX", reason: "New Member",count: "40"},
        { program: "HBEX", reason: "Renewal",count: "100"},
        { program: "HBEX", reason: "Termed Enrollment",count: "30"},
        { program: "HBEX", reason: "Cancelled Enrollment",count: "10"},
        { program: "HBEX", reason: "Effectuated Enrollment",count: "32"},
        { program: "HBEX", reason: "Un Effectuated Enrollment",count: "15"},
        { program: "HBEX", reason: "Under GP Restriction",count: "21"},
        { program: "HBEX", reason: "Active Enrollment with PCP",count: "38"},
        { program: "HBEX", reason: "Active Enrollment with out PCP",count: "2"}
      ];
    }
    else if (program=="CMC") {
      this.enrollmentDetails = [      
        { program: "CMC", reason: "No of Active Enrollment ",count: "100"},     
        { program: "CMC", reason: "Active Enrollment with PCP",count: "48"},
        { program: "CMC", reason: "Active Enrollment with out PCP",count: "70"}
      ]; 
    } 
    else if (program=="MCLA") {
      this.enrollmentDetails = [      
        { program: "MCLA", reason: "No of Active Enrollment ",count: "140"},     
        { program: "MCLA", reason: "Active Enrollment with PCP",count: "68"},
        { program: "MCLA", reason: "Active Enrollment with out PCP",count: "20"}
      ] 
    }  
    else {
      this.enrollmentDetails = [      
        { program: "PASC", reason: "No of Active Enrollment ",count: "890"},     
        { program: "PASC", reason: "Active Enrollment with PCP",count: "568"},
        { program: "PASC", reason: "Active Enrollment with out PCP",count: "90"}
      ]       
    }
  }

  modalPopup(hc: any){
      this.title = hc.program + ' - ' + hc.reason + ' Details';  
      this.memberDetails = [
        {memId: "123", fullName: "aalala", dob: "19/08/1993", gender: "male", ssn: "451442655", enrollId: "E123", effDate: "01/01/2019", termDate: "12/31/2019",carrierMemId: "5723839",rateCode:"R001" },
        {memId: "123", fullName: "aalala", dob: "19/08/1993", gender: "male", ssn: "451442655", enrollId: "E123", effDate: "01/01/2019", termDate: "12/31/2019",carrierMemId: "5723839",rateCode:"R001" },
        {memId: "123", fullName: "aalala", dob: "19/08/1993", gender: "male", ssn: "451442655", enrollId: "E123", effDate: "01/01/2019", termDate: "12/31/2019",carrierMemId: "5723839",rateCode:"R001" },
        {memId: "123", fullName: "aalala", dob: "19/08/1993", gender: "male", ssn: "451442655", enrollId: "E123", effDate: "01/01/2019", termDate: "12/31/2019",carrierMemId: "5723839",rateCode:"R001" },
        {memId: "123", fullName: "aalala", dob: "19/08/1993", gender: "male", ssn: "451442655", enrollId: "E123", effDate: "01/01/2019", termDate: "12/31/2019",carrierMemId: "5723839",rateCode:"R001" },
        {memId: "546", fullName: "sundar", dob: "9/08/1993", gender: "male", ssn: "451563455", enrollId: "E124", effDate: "01/01/2019", termDate: "12/31/2019",carrierMemId: "5723459",rateCode:"R002" },
        {memId: "546", fullName: "sundar", dob: "29/08/1993", gender: "male", ssn: "455634655", enrollId: "E243", effDate: "01/01/2019", termDate: "12/31/2019",carrierMemId: "5734539",rateCode:"R021" },
        {memId: "546", fullName: "sundar", dob: "1/08/1993", gender: "male", ssn: "451563455", enrollId: "E124", effDate: "01/01/2019", termDate: "12/31/2019",carrierMemId: "5723459",rateCode:"R002" },
        {memId: "546", fullName: "sundar", dob: "15/08/1993", gender: "male", ssn: "455634655", enrollId: "E243", effDate: "01/01/2019", termDate: "12/31/2019",carrierMemId: "5734539",rateCode:"R021" },
        {memId: "546", fullName: "sundar", dob: "17/08/1993", gender: "male", ssn: "455634655", enrollId: "E243", effDate: "01/01/2019", termDate: "12/31/2019",carrierMemId: "5734539",rateCode:"R021" }

      ];
  }

  generateExcel() {       
    this.excelService.generateExcel(this.title,this.memberDetails);
  }
}
