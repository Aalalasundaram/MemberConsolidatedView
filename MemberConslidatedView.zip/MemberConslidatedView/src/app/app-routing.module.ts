import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EnrollmentComponent } from './enrollment/enrollment.component';
import { MemberListComponent } from './member-list/member-list.component';
import { NewComponent } from './new/new.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  // {path: 'memberlist/:firstName/:lastName', component: MemberListComponent},
  {path: 'memberlist/:memId', component: MemberListComponent},
  {path: 'enrollment', component: EnrollmentComponent},
  {path: 'new',component: NewComponent},
  {path: 'home', component: HomeComponent},
  {path: '', redirectTo: '/home', pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
