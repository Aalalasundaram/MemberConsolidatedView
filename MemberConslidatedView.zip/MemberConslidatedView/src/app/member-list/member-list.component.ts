import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-member-list',
  templateUrl: './member-list.component.html',
  styleUrls: ['./member-list.component.css']
})
export class MemberListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    this.enrollmentDetails = [      
      { enrollment: "Sponsar", primary: "AAAAAAAA",secondary: "RRRRRRRRRR"},
      { enrollment: "Benefit Plan", primary: "BBBBBBB",secondary: "TTTTTTTT"},
      { enrollment: "Restriction", primary: "WWWWWWWWW",secondary: "QQQQQQQQ"},
      { enrollment: "Effective Date", primary: "01/01/2019 ",secondary: "12/31/2019 "},
      { enrollment: "Term Date", primary: "01/01/2019 ",secondary: "12/31/2019 "},
      { enrollment: "Type", primary: "DDDDDDDDDDD",secondary: "JJJJJJJJ"}      
    ];    

    this.pcpDetails = [
      { desc: "Primary Care Physican (PCP/PDP)", value1: "AAAAAAAA",value2: "RRRRRRRRRR"},
      { desc: "Affiliation", value1: "ddadds",value2: "adsdasds"},
      { desc: "Address1", value1: "Wasdasdsd",value2: "Vdfdfff"},
      { desc: "Address2", value1: "Pasdasdsds",value2: "Afasdfsdsd"},
      { desc: "City, State, Zip Code", value1: "GH, RF,123654 ",value2: "UH, TH, 654321 "},
      { desc: "Phone", value1: "9875463215",value2: "6587452312"}
    ];

    this.subsidyDetails=[
      { type: "APTC ", amount: "5000",effdate: "01/01/2019",termdate: "12/31/2019"},
      { type: "CSR", amount: "100",effdate: "01/01/2019",termdate: "12/31/2019"}
    ];

    this.restrictionDetails=[
      { type: "Grace1",effdate: "10/01/2019",termdate: "10/31/2019"},
      { type: "Grace2",effdate: "11/01/2019 ",termdate: "12/31/2019"}
    ];
    this.actionDetails=[
      { type: "Issue Id",status: "Completed",completeDate: "10/31/2019"},
      { type: "ReIssue Id",status: "",completeDate: ""}
    ];   
    
    this.claimDetails = [
      { enrollId: "Enr001",claimId: "Clm001",claimData: "08/01/2019",claimAmount:"1000",status:"Paid",paidAmount:"900",paidDate:"08/31/2019"}    
    ];

    this.accumulatorDetails = [
      {desc:"Individual Med Deduct",amt:"1250"},
      {desc:"Family Med Deduct",amt:"754"},
      {desc:"Individual Max OOP",amt:"852"},
      {desc:"Family Max OOP",amt:"963"},
      {desc:"Individual Pharma Deduct",amt:"121"},
      {desc:"Family Pharma Deduct",amt:"970"},
      {desc:"Individual CoPay",amt:"550"},
      {desc:"Individual CoInsurance",amt:"690"},
      {desc:"Family CoPay",amt:"150"},
      {desc:"Family CoInsurance",amt:"550"},
    ];

    this.dependentDetails = [
      {name:"Test1, Test22",dob:"01/01/1960 ",gender:"M",ssn:"1236548975",relationShip:"Self",subscriber:"Test1, Test22",subscriberId:"",linkedNumber:""},
      {name:"Test5, Test22",dob:"01/01/1953 ",gender:"F",ssn:"9865321459",relationShip:"Spouse",subscriber:"Test5, Test22",subscriberId:"",linkedNumber:""}
    ];
  }

  enrollmentDetails = [];
  pcpDetails = [];
  subsidyDetails = [];
  restrictionDetails = [];
  actionDetails = [];
  claimDetails = [];
  accumulatorDetails = [];
  dependentDetails = [];

}
