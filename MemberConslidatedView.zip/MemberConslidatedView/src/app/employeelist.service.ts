import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';  
import { HttpClient } from '../../node_modules/@angular/common/http';
import { IEmployee } from '../assets/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeelistService {

  private _url:string = "/assets/data/employee.json";

  constructor(private http : HttpClient) { }

  getEmployeelist(): Observable<IEmployee[]>{
    return this.http.get<IEmployee[]>(this._url);
  }  
}
