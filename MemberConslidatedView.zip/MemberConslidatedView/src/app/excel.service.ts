import { Injectable } from '@angular/core';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
import { DatePipe } from '../../node_modules/@angular/common';
@Injectable({
  providedIn: 'root'
})
export class ExcelService {


  constructor(private datePipe: DatePipe) {

  }

  generateExcel(excelTitle,datas) {
    
    //Excel Title, Header, Data
    const title = excelTitle;
    const header = ["Mem Id","Full Name","Date Of Birth"," Gender","SSN","Enroll Id","Eff Date","Term Date","Carrier MemId","Ratecode"];
    const data = [];
    const list = [];
    for(let value of datas){
      const list = [];
      list.push(value.memId);
      list.push(value.fullName);
      list.push(value.dob);
      list.push(value.gender);
      list.push(value.ssn);
      list.push(value.enrollId);
      list.push(value.effDate);
      list.push(value.termDate);
      list.push(value.carrierMemId);
      list.push(value.rateCode);
      data.push(list);
    }
    
    //Create workbook and worksheet
    let workbook = new Workbook();
    let worksheet = workbook.addWorksheet('Data');


    //Add Row and formatting
    let titleRow = worksheet.addRow([title]);
    //titleRow.font = { name: 'Comic Sans MS', family: 4, size: 16, underline: 'double', bold: true }
    worksheet.addRow([]);
    let subTitleRow = worksheet.addRow(['Date : ' + this.datePipe.transform(new Date(), 'medium')])

    //Blank Row 
    worksheet.addRow([]);

    //Add Header Row
    let headerRow = worksheet.addRow(header);
    
    // Cell Style : Fill and Border
    headerRow.eachCell((cell, number) => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: '77ddf4' },
        bgColor: { argb: '77ddf4' }
      }
      cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
    })
      
    //worksheet.addRows(data); 
    data.forEach(d => 
    {
      let row = worksheet.addRow(d);
      row.eachCell((cell, number) => {
        cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } }
      })  
    })
    
    //Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data) => {
      let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      fs.saveAs(blob, excelTitle + '.xlsx');
    })

  }
}